package com.webapp.controller;

import com.webapp.modal.StudentModal;
import com.webapp.services.StudentServices;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "StudentController", urlPatterns = {"/StudentController"})
public class StudentController extends HttpServlet {

    String message = null;
    StudentServices ss = new StudentServices();
    StudentModal sm = new StudentModal();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        switch (action) {
            case "insert":
                // code for insert data
                insertStudent(request, response);
                break;
            case "update":
                // code for update data
                break;
            case "delete":
                // code for Delete record
                break;
            default:
                break;
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void insertStudent(HttpServletRequest request, HttpServletResponse response) throws IOException {

        // create obj of studmodal for usind setters methods
       
        sm.setName(request.getParameter("name"));
        sm.setEmail(request.getParameter("email"));
        sm.setPhone(request.getParameter("phone"));
        sm.setBranch(request.getParameter("branch"));
        sm.setAddress(request.getParameter("address"));
        sm.setCity(request.getParameter("city"));
        sm.setState(request.getParameter("state"));
        
        message = ss.insertStudent(sm);


        response.sendRedirect("StudentAll.jsp?msg=" + message);
    }

    // Select Method to show all record
    public ArrayList<StudentModal> selectAll(){
        
        return ss.selectAll();
    }
    
    
    
    //Show only one record by id
    
    public StudentModal selectById(int id){
            
        return ss.selectById(id);
        
        
    }

  
}
