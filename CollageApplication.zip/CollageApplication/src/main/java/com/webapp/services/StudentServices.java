
package com.webapp.services;

import com.webapp.dao.StudentDao;
import com.webapp.modal.StudentModal;
import java.util.ArrayList;


public class StudentServices {
    
    StudentDao sd = new StudentDao();
    
    public String insertStudent (StudentModal sm) {
        return sd.insertStudent(sm);
        
    }

    public ArrayList<StudentModal> selectAll() {
        
        return sd.selectAll();
    }

    public StudentModal selectById(int id) {
        
    return sd.selectById(id);
    }
    
        
}
